#!/bin/bash

apt-get install -y libcjson-dev

echo -e "\033[1;32m 05_install_cjson.sh script has finished running."
echo -e "\033[0m"
