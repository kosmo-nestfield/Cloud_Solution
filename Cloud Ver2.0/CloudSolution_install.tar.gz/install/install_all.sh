#!/bin/bash

./01_install.sh && ./02_install_python.sh && ./03_install_python_package.sh && ./04_install_rabbitmq.sh && ./05_install_cjson.sh && ./06_install_open62541.sh && ./07_install_rabbitmq-c.sh && ./08_install_influx.sh && ./09_install_Lynis.sh && ./10_install_mariadb.sh && ./11_install_grafana.sh && ./12_install_nginx.sh && ./13_install_certbot.sh && ./14_install_systemctl_service.sh && ./15_install_default_config.sh
