#!/bin/bash

snap install --classic certbot

echo -e "\033[1;32m 13_install_certbot.sh script has finished running."
echo -e "\033[0m"
