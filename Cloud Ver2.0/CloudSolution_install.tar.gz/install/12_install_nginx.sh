#!/bin/bash

sudo apt-get update
sudo apt-get install -y nginx

echo -e "\033[1;32m 12_install_nginx.sh script has finished running."
echo -e "\033[0m"
