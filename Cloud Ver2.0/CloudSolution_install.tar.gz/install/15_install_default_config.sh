#!/bin/bash

cd /opt/install/configs
sudo cp 50-server.cnf /etc/mysql/mariadb.conf.d/
sudo cp nginx.conf /etc/nginx/
sudo cp default /etc/nginx/sites-available/
sudo cp grafana.ini /etc/grafana/
sudo cp settings.py /opt/apps/django/SmartFactory/config/

cd /opt/install
gzip -d libopen62541_cloud.tar.gz
cd /usr/local/lib
cp /opt/install/libopen62541_cloud.tar ./
tar xvf libopen62541_cloud.tar
#rm libopen62541.so.1
ln -sf libopen62541.so.0.0.0 libopen62541.so.0
chown root:root libopen62541.so.0.0.0

cd /opt/install
./restart_services.sh

echo -e "\033[1;32m 15_install_default_config.sh script has finished running."
echo -e "\033[0m"
