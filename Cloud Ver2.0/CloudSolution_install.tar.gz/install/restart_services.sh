#!/bin/sh

sudo systemctl restart gather
sudo systemctl restart nginx
sudo systemctl restart django
sudo systemctl restart itsdb
sudo systemctl restart grafana-server
