#!/bin/bash

git clone https://github.com/CISOfy/lynis

echo -e "\033[1;32m 09_install_Lynis.sh script has finished running."
echo -e "\033[0m"
